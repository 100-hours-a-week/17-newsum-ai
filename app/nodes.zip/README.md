# 17-team-4cut 에이전트 시스템

## 개요

이 디렉토리는 뉴스 기사를 기반으로 4컷 만화를 자동으로 생성하는 AI 시스템의 에이전트(Agent) 모듈들을 포함하고 있습니다. 각 에이전트는 전체 만화 생성 파이프라인에서 특정 작업을 담당하며, 순차적으로 실행되어 최종 결과물을 생성합니다.

## 워크플로우 구조

파일명은 실행 순서를 나타내는 숫자 접두사를 포함하고 있으며, 워크플로우는 다음과 같은 순서로 진행됩니다:

```
initialize → topic_analyzer → collector → scraper → individual_summarizer → synthesis_summarizer → 
evaluate_summary → content_summarizer → sentiment_analyzer → humorator → 
scenariowriter → imager → translator → postprocessor
```

## 에이전트 목록 및 기능 설명

### 1. Initialize Agent (`01_initialize_agent.py`)

- **목적**: 워크플로우 초기화 및 고유 ID 할당
- **주요 기능**:
  - 사용자 쿼리(`initial_query`) 존재 여부 검증
  - UUID를 사용한 고유 `comic_id` 생성
- **입력**: `initial_query` (사용자 검색어)
- **출력**: 
  - `comic_id`: 고유 식별자
  - `error_message`: 오류 발생 시 메시지

### 2. Topic Analyzer Agent (`02_topic_analyzer_agent.py`)

- **목적**: 사용자 쿼리 심층 분석 및 구조화
- **주요 기능**:
  - LLM을 활용한 쿼리 주제 분석
  - 핵심 주제, 주요 엔티티, 최근 동향 식별
  - 만화 제작을 위한 창의적 각도 제안
  - 검색 최적화 키워드 생성
- **입력**: `initial_query`
- **출력**:
  - `topic_analysis`: 구조화된 주제 분석 결과 (JSON)
    - `core_topic`: 핵심 주제
    - `key_entities`: 주요 엔티티 목록
    - `recent_developments`: 최근 동향
    - `potential_angles`: 창의적 접근법
    - `search_keywords`: 검색 키워드

### 3. Collector Agent (`03_collector_agent.py`)

- **목적**: 검색 엔진을 통한 관련 뉴스 URL 수집
- **주요 기능**:
  - 다양한 검색 엔진 지원 (Google, Tavily, Naver, Kakao)
  - 한국 관련 키워드 감지 시 Naver 검색 추가 수행
  - 검색 실패 시 대체 엔진으로 폴백
  - LLM을 활용한 URL 필터링
- **입력**:
  - `initial_query`: 사용자 검색어
  - `topic_analysis`: 주제 분석 결과 (검색 키워드 활용)
- **출력**:
  - `news_urls`: 뉴스 URL 리스트
  - `selected_url`: 대표 URL (하위 호환성용)
  - `search_results`: 전체 검색 결과

### 4. Scraper Agent (`04_scraper_agent.py`)

- **목적**: 수집된 URL에서 뉴스 기사 본문 추출
- **주요 기능**:
  - 비동기 병렬 스크래핑 (여러 URL 동시 처리)
  - 다양한 웹사이트 구조 대응을 위한 CSS 선택자 패턴
  - 광고, 스크립트 등 불필요 요소 제거
- **입력**: `news_urls`
- **출력**: `articles`: 뉴스 본문 리스트

### 5. Individual Summarizer Agent (`05_individual_summarizer_agent.py`)

- **목적**: 각 뉴스 기사 개별 요약
- **주요 기능**:
  - 비동기 병렬 요약 (여러 기사 동시 처리)
  - LLM을 활용한 기사별 핵심 내용 추출
- **입력**: `articles`
- **출력**: `summaries`: 개별 기사 요약 리스트

### 6. Synthesis Summarizer Agent (`06_synthesis_summarizer_agent.py`)

- **목적**: 개별 요약들을 종합하여 통합 요약 생성
- **주요 기능**:
  - 여러 요약을 메타-요약하여 핵심 내용 통합
  - 공통 주제 및 연결점 식별
- **입력**: `summaries`
- **출력**: `final_summary`: 최종 통합 요약

### 7. Evaluate Summary Agent (`07_evaluate_summary_agent.py`)

- **목적**: 요약 품질 평가 및 워크플로우 방향 결정
- **주요 기능**:
  - 생성된 요약(`final_summary`)을 토픽 분석(`topic_analysis`) 결과와 비교 평가
  - 다음 단계 결정: 진행/재검색/주제 재분석
  - 결정에 대한 설명 제공
- **입력**:
  - `final_summary`: 통합 요약
  - `topic_analysis`: 주제 분석 결과
- **출력**:
  - `summary_evaluation_decision`: 결정 ("proceed", "research_again", "refine_topic")
  - `summary_evaluation_comment`: 결정 근거

### 8. Content Summarizer Agent (`08_content_summarizer_agent.py`)

- **목적**: YouTube 등에서 추가 컨텍스트 수집 및 분석
- **주요 기능**:
  - YouTube API를 통한 관련 비디오 검색
  - 비디오 캡션, 댓글, 메타데이터 수집
  - 추가 컨텍스트 및 관점 요약
- **입력**:
  - `final_summary` 또는 `initial_query`
- **출력**:
  - `additional_context`: 추가 컨텍스트 정보
    - `summary`: 요약된 추가 정보
    - `perspectives`: 추가적인 관점 리스트

### 9. Sentiment Analyzer Agent (`09_sentiment_analyzer_agent.py`)

- **목적**: YouTube 댓글 기반 대중 감정 분석
- **주요 기능**:
  - YouTube API를 통한 관련 비디오 검색 및 댓글 수집
  - 감정 분석 (긍정/부정/중립)
  - 감정 유형 분석 (분노, 슬픔, 기쁨, 두려움, 놀람)
- **입력**:
  - `final_summary` 또는 `initial_query`
- **출력**:
  - `public_sentiment`: 감정 분석 결과
    - `sentiment`: 감정 비율 (긍정/부정/중립)
    - `emotions`: 감정 유형 비율

### 10. Humorator Agent (`10_humorator_agent.py`)

- **목적**: 뉴스 내용에서 유머 요소 추출
- **주요 기능**:
  - 공감적(empathetic) 유머 포인트 식별
  - 아이러니, 모순, 부조리 등 유머 요소 발굴
  - 윤리적 가이드라인 적용 (약자 조롱 방지)
- **입력**:
  - `final_summary`: 최종 요약
  - `additional_context`: 추가 컨텍스트
- **출력**:
  - `humor_texts`: 유머 요소 리스트

### 11. Scenario Writer Agent (`11_scenariowriter_agent.py`)

- **목적**: 4컷 만화 시나리오 작성
- **주요 기능**:
  - 뉴스 요약, 유머 요소, 감정 분석 결과 활용
  - 4컷 구조의 시나리오 생성
  - 각 컷별 장면 묘사 및 대사 생성
- **입력**:
  - `final_summary`: 최종 요약
  - `humor_texts`: 유머 요소
  - `public_sentiment`: 감정 분석 결과
- **출력**:
  - `scenarios`: 4컷 시나리오 (각 컷은 `description`과 `dialogue` 포함)

### 12. Imager Agent (`12_imager_agent.py`)

- **목적**: 시나리오 기반 이미지 생성
- **주요 기능**:
  - 각 컷의 장면 묘사를 기반으로 이미지 생성
  - 외부 이미지 생성 서비스 연동
- **입력**: `scenarios`
- **출력**: `image_urls`: 생성된 이미지 URL 리스트

### 13. Translator Agent (`13_translator_agent.py`)

- **목적**: 생성된 텍스트 다국어 번역 (옵션)
- **상태**: 구현 예정 (TODO)
- **입력**: 대사 텍스트
- **출력**: 번역된 대사 텍스트

### 14. Post Processor Agent (`14_postprocessor_agent.py`)

- **목적**: 이미지와 대사를 조합하여 최종 만화 생성
- **상태**: 구현 예정 (TODO)
- **입력**:
  - `image_urls`: 이미지 URL
  - 대사 텍스트
- **출력**: 최종 4컷 만화 파일

## 에이전트 공통 인터페이스

모든 에이전트는 다음과 같은 공통 인터페이스를 구현하고 있습니다:

```python
async def run(self, state: ComicState) -> Dict[str, Optional[Any]]:
    """
    에이전트의 메인 실행 함수
    
    Args:
        state: 현재까지의 워크플로우 상태를 포함하는 ComicState 객체
        
    Returns:
        Dict[str, Optional[Any]]: 상태 업데이트를 위한 딕셔너리
    """
```

## 상태 관리

- 에이전트 간 데이터는 `ComicState` 객체를 통해 전달됩니다.
- 각 에이전트는 상태를 직접 수정하지 않고, 상태 업데이트를 위한 딕셔너리를 반환합니다.
- 워크플로우 엔진이 이 업데이트 딕셔너리를 기반으로 상태를 갱신합니다.

## 오류 처리

- 각 에이전트는 자체적으로 예외를 포착하고 처리합니다.
- 오류 발생 시 `error_message` 필드에 메시지를 포함하여 상태를 반환합니다.
- 워크플로우 엔진은 이 오류 메시지를 기반으로 후속 조치를 결정합니다.

## 기술 스택

- **비동기 처리**: asyncio를 활용한 병렬 처리
- **HTTP 클라이언트**: httpx 활용
- **HTML 파싱**: BeautifulSoup4 활용
- **LLM 통합**: app.services.llm_server_client 모듈 활용
- **이미지 생성**: app.services.image_server_client 모듈 활용
- **로깅**: app.utils.logger 모듈의 get_logger 함수 활용

## 워크플로우 최적화 기능

### 토픽 분석 및 요약 평가 루프

시스템은 `TopicAnalyzerAgent`, `CollectorAgent`, 스크래핑 및 요약 단계를 거쳐 `EvaluateSummaryAgent`에서 품질을 평가합니다. 평가 결과에 따라:

1. **proceed**: 만화 생성 워크플로우 계속 진행
2. **research_again**: 현재 주제로 더 나은 기사 재검색 (`CollectorAgent`로 돌아감)
3. **refine_topic**: 주제 재정의 필요 (`TopicAnalyzerAgent`로 돌아감)

이 피드백 루프를 통해 최종 만화 생성 전 품질 개선이 가능합니다.

## 개발자 가이드

### 에이전트 개발 원칙

1. **비동기 처리**: 모든 에이전트는 `async/await` 패턴을 따라야 합니다.
2. **상태 변경**: 직접 상태를 수정하지 말고 업데이트 딕셔너리를 반환해야 합니다.
3. **예외 처리**: 모든 외부 API 호출 및 처리 로직은 적절한 예외 처리를 포함해야 합니다.
4. **로깅**: 주요 단계 및 오류에 대한 상세 로그를 남겨야 합니다.
5. **의존성 주입**: 테스트 용이성을 위해 외부 의존성은 주입 가능하도록 설계합니다.

### 신규 에이전트 추가 방법

1. 파일명은 `XX_agent_name_agent.py` 형식을 따릅니다.
2. 공통 인터페이스(`run` 메서드)를 구현합니다.
3. 필요한 의존성은 생성자에서 초기화하거나 주입받습니다.
4. 구현 후 워크플로우 설정에 통합합니다.

## 향후 개발 계획

1. **번역 기능 구현**: `TranslatorAgent` 완성
2. **후처리 기능 구현**: `PostProcessorAgent` 완성
3. **에이전트 간 병렬 처리 최적화**: 독립적인 작업의 병렬 실행
4. **캐싱 메커니즘 도입**: 반복 요청 최적화
5. **모니터링 및 로깅 고도화**: 상세 진단 및 성능 분석 지원