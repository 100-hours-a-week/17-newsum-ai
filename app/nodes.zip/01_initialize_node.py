import logging
import uuid
from typing import Dict, Optional, Any
from app.workflows.state import ComicState

logger = logging.getLogger(__name__)

class InitializeAgent:
    """
    Agent that initializes the ComicState with a unique comic_id and validates the initial query.
    """
    
    async def run(self, state: ComicState) -> Dict[str, Optional[Any]]:
        """
        1. Validate that initial_query exists
        2. Generate and assign a unique comic_id
        3. Return a dictionary of updates to merge into the state
        """
        logger.info("--- [Initialize Agent] Starting execution ---")
        updates: Dict[str, Optional[Any]] = {}
        
        # Validate initial query
        if not state.initial_query:
            logger.error("[Initialize Agent] No initial query provided.")
            updates["error_message"] = "Initial query is missing."
        else:
            updates["error_message"] = None
            
        # Generate unique comic_id
        comic_id = str(uuid.uuid4())
        updates["comic_id"] = comic_id
        logger.info(f"[Initialize Agent] Assigned comic_id: {comic_id}")
        
        logger.info("--- [Initialize Agent] Execution complete ---")
        return updates