import json
from typing import Dict, Optional, Any
from app.workflows.state import ComicState
from app.services.llm_server_client import LLMServerClient
from app.utils.logger import get_logger

logger = get_logger(__name__)

class TopicAnalyzerAgent:
    """
    Agent that analyzes the initial query to produce structured topic analysis,
    including core topic, key entities, recent developments, potential angles,
    and search keywords for news retrieval.
    """
    def __init__(self):
        try:
            self.llm_client = LLMServerClient()
            logger.debug("TopicAnalyzerAgent initialized with LLM client.")
        except Exception as e:
            logger.exception("Failed to initialize LLMServerClient in TopicAnalyzerAgent", exc_info=True)
            self.llm_client = None

    def _build_prompt(self, query: str) -> str:
        """
        Constructs the LLM prompt for analyzing the user query.
        """
        prompt_template = '''
Analyze the following news query for the purpose of generating a 4-panel news comic.
Your goal is to provide a structured analysis that helps in finding relevant recent news articles and identifying potential angles for the comic.

News Query: "{query}"

Please provide your analysis in a single, valid JSON object containing ONLY the following keys:
1.  "core_topic": (String) A concise description of the main subject or event.
2.  "key_entities": (List of Strings) Important people, organizations, or places related to the query.
3.  "recent_developments": (List of Strings) Specific recent events, updates, or subtopics (2–4 items).
4.  "potential_angles": (List of Strings) Creative or humorous angles for a 4-panel comic (3–5 items).
5.  "search_keywords": (List of Strings) Keywords optimized for searching recent Korean news (5–7 items).

Ensure the output is ONLY the JSON object and nothing else.
'''
        return prompt_template.format(query=query)

    async def run(self, state: ComicState) -> Dict[str, Optional[Any]]:
        """
        Executes topic analysis:
        - Validates LLM client and initial query
        - Builds prompt, calls LLM
        - Cleans and parses JSON response
        - Returns updates for state: {'topic_analysis': ..., 'error_message': ...}
        """
        comic_id = state.comic_id or "UNKNOWN_ID"
        logger.info(f"--- [{comic_id}] [Topic Analyzer Agent] Starting execution ---")
        updates: Dict[str, Optional[Any]] = {"topic_analysis": None, "error_message": None}

        # Check LLM client
        if not self.llm_client:
            err = "TopicAnalyzerAgent not ready (LLM client init failed)"
            logger.error(f"[{comic_id}] {err}")
            updates["error_message"] = err
            return updates

        # Validate initial query
        query = state.initial_query
        if not query:
            err = "Initial query is missing for topic analysis."
            logger.error(f"[{comic_id}] {err}")
            updates["error_message"] = err
            return updates

        # Build and log prompt
        prompt = self._build_prompt(query)
        logger.debug(f"[{comic_id}] Prompt for topic analysis: {prompt[:300]}...")

        try:
            # Call LLM
            logger.info(f"[{comic_id}] Calling LLM for topic analysis...")
            raw_response = await self.llm_client.call_llm_api(prompt=prompt)
            logger.info(f"[{comic_id}] LLM response received.")
            logger.debug(f"[{comic_id}] Raw LLM response: {raw_response[:300]}...")

            # Clean code fences
            cleaned = raw_response.strip()
            if cleaned.startswith("```json"):
                cleaned = cleaned[7:]
                if cleaned.endswith("```"):
                    cleaned = cleaned[:-3]
            elif cleaned.startswith("```"):
                cleaned = cleaned[3:]
                if cleaned.endswith("```"):
                    cleaned = cleaned[:-3]

            # Parse JSON
            parsed = json.loads(cleaned.strip())

            # Validate keys
            required = {"core_topic", "key_entities", "recent_developments", "potential_angles", "search_keywords"}
            if isinstance(parsed, dict) and required.issubset(parsed.keys()):
                updates["topic_analysis"] = parsed
                logger.info(f"[{comic_id}] Topic analysis parsed successfully.")
                logger.debug(f"[{comic_id}] Parsed analysis: {json.dumps(parsed, ensure_ascii=False, indent=2)}")
            else:
                missing = required - set(parsed.keys()) if isinstance(parsed, dict) else required
                err = f"LLM response JSON missing keys: {missing}"
                logger.error(f"[{comic_id}] {err}")
                updates["error_message"] = err

        except json.JSONDecodeError as jde:
            err = f"JSON parsing failed: {jde}"
            logger.error(f"[{comic_id}] {err}")
            updates["error_message"] = err
        except Exception as e:
            err = f"LLM API call failed: {e}"
            logger.exception(f"[{comic_id}] {err}")
            updates["error_message"] = err

        logger.info(f"--- [{comic_id}] [Topic Analyzer Agent] Execution complete ---")
        return updates