# app/agents/evaluate_summary_agent.py

import json
import logging # Use logging configured by get_logger
from typing import Dict, Optional, Any, Set

from app.workflows.state import ComicState
from app.services.llm_server_client import LLMServerClient
from app.utils.logger import get_logger

logger = get_logger(__name__) # 설정된 로거 사용

# 유효한 평가 결정 값 집합
VALID_DECISIONS: Set[str] = {"proceed", "research_again", "refine_topic"}

class EvaluateSummaryAgent:
    """
    생성된 요약(`final_summary`)의 품질과 관련성을 초기 토픽 분석(`topic_analysis`) 결과와
    비교 평가하여, 다음 워크플로우 단계를 결정하는 에이전트입니다:
    'proceed'(진행), 'research_again'(재검색), or 'refine_topic'(주제 재분석).
    선택적으로 평가 근거('comment')를 포함합니다.
    """
    # MAX_RETRIES는 이 에이전트가 아닌 조건부 엣지 로직에서 처리합니다.
    # 여기에 정의하는 것은 정보 제공 목적일 뿐, 에이전트 기능에는 영향을 주지 않습니다.
    # MAX_RETRIES = 2 # 필요 시 참고용으로 남겨둘 수 있음

    def __init__(self, llm_client: Optional[LLMServerClient] = None):
        """
        에이전트를 초기화하고 LLM 클라이언트를 설정합니다.
        (테스트 용이성을 위해 외부에서 주입 가능)
        """
        try:
            self.llm_client = llm_client or LLMServerClient()
            if not self.llm_client:
                # LLM 클라이언트 초기화 실패는 심각한 문제일 수 있음
                raise ValueError("LLM Client could not be initialized for EvaluateSummaryAgent.")
            logger.debug("EvaluateSummaryAgent initialized with LLM client.")
        except Exception as e:
            # 초기화 실패 시 로깅 후 None으로 설정하여 run 메서드에서 확인 가능하도록 함
            logger.exception("Failed to initialize LLMServerClient in EvaluateSummaryAgent", exc_info=True)
            self.llm_client = None

    def _build_prompt(self, final_summary: str, topic_analysis: Dict[str, Any]) -> str:
        """토픽 분석 결과를 바탕으로 요약 평가를 위한 LLM 프롬프트를 구성합니다."""
        # topic_analysis에서 컨텍스트 정보 안전하게 추출
        core_topic = topic_analysis.get('core_topic', 'N/A')
        key_entities = topic_analysis.get('key_entities', [])
        recent_devs = topic_analysis.get('recent_developments', [])

        # 리스트 정보를 프롬프트 가독성 좋게 문자열로 변환
        entities_str = ", ".join(key_entities) if key_entities else 'N/A'
        devs_str = "; ".join(recent_devs) if recent_devs else 'N/A'

        # 프롬프트 템플릿 - MAX_RETRIES 관련 문구 제거됨
        # 요약 길이 제한 적용 (예: 3000자)
        prompt = f"""
You are an AI assistant evaluating a news summary for a 4-panel comic workflow.
Evaluate the 'Generated Summary' based on the provided 'Context'.

Context:
- Core Topic: {core_topic}
- Key Entities: {entities_str}
- Recent Developments Expected: {devs_str}

Generated Summary:
---
{final_summary.strip()[:3000]}
---

Task:
Assess the 'Generated Summary' for its relevance, factual plausibility (based on general knowledge of news), and sufficiency based on the 'Context'. Decide whether to:
- "proceed": The summary accurately reflects the context and is sufficient to continue the workflow.
- "research_again": The summary is insufficient, lacks key details, misses recent developments, seems off-topic based on the context, or raises factual concerns; better source articles are needed for the *current* topic definition.
- "refine_topic": The summary indicates the *initial context itself* (Core Topic, Developments) might be flawed, misinterpreted, too broad, or too narrow; the original query needs re-analysis before searching again.

Respond ONLY with a valid JSON object containing the following keys:
{{
  "decision": "<one_of_the_three_valid_strings: 'proceed', 'research_again', 'refine_topic'>",
  "comment": "<optional_string_providing_a_brief_rationale_for_your_decision>"
}}
Do not include any text before or after the JSON object.
"""
        return prompt

    def _clean_and_parse_response(self, response: str, comic_id: str) -> Optional[Dict[str, Any]]:
        """LLM 응답에서 코드 펜스를 제거하고 JSON으로 파싱합니다."""
        logger.debug(f"[{comic_id}] Cleaning and parsing LLM evaluation response...")
        # 코드 펜스 제거 (더 안정적인 방식 사용)
        text = response.strip()
        if text.startswith("```json"):
            text = text[7:]
            if text.endswith("```"):
                text = text[:-3]
        elif text.startswith("```"):
            text = text[3:]
            if text.endswith("```"):
                text = text[:-3]
        text = text.strip()

        # 비어있는 응답 처리
        if not text:
            logger.warning(f"[{comic_id}] LLM response for evaluation was empty after cleaning.")
            return None
        try:
            # JSON 파싱
            parsed_data = json.loads(text)
            logger.debug(f"[{comic_id}] Successfully parsed JSON evaluation response.")
            return parsed_data
        except json.JSONDecodeError as e:
            # 파싱 에러 로깅
            logger.error(f"[{comic_id}] JSON parsing error during evaluation: {e}. Response snippet: {text[:200]}...")
            return None # 파싱 실패 시 None 반환

    async def run(self, state: ComicState) -> Dict[str, Optional[Any]]:
        """요약 평가 로직 실행 및 상태 업데이트 반환."""
        # comic_id 안전하게 가져오기
        comic_id = getattr(state, 'comic_id', 'UNKNOWN_ID')
        logger.info(f"--- [{comic_id}] [Evaluate Summary Agent] Execution Started ---")

        # 상태 업데이트 딕셔너리 초기화 (기본 결정값 설정)
        # 오류 발생 시 워크플로우 정지를 피하기 위해 'proceed'를 기본값으로 설정.
        # 더 엄격한 처리가 필요하면 None이나 다른 값으로 변경 가능.
        updates: Dict[str, Optional[Any]] = {
            "summary_evaluation_decision": "proceed",
            "summary_evaluation_comment": None,
            "error_message": None
        }

        # --- 사전 조건 검사 ---
        if not self.llm_client:
            err = "EvaluateSummaryAgent not ready (LLM client init failed)"
            logger.error(f"[{comic_id}] {err}")
            updates["error_message"] = err
            return updates # 클라이언트 없으면 기본값 반환

        final_summary = getattr(state, 'final_summary', None)
        topic_analysis = getattr(state, 'topic_analysis', None)

        if not final_summary or not topic_analysis:
            # 필수 입력 누락 시 경고 로깅 후 기본값 'proceed' 반환
            logger.warning(f"[{comic_id}] Missing final_summary or topic_analysis for evaluation. Defaulting to 'proceed'.")
            # 필요하다면 에러 메시지 설정: updates['error_message'] = "Missing data for evaluation."
            return updates
        # --- 사전 조건 검사 종료 ---

        # --- 핵심 로직 ---
        try:
            # 1. 프롬프트 생성
            prompt = self._build_prompt(final_summary, topic_analysis)
            logger.debug(f"[{comic_id}] Built evaluation prompt (first 300 chars): {prompt[:300]}...")

            # 2. LLM API 호출
            logger.info(f"[{comic_id}] Calling LLM for summary evaluation...")
            raw_response = await self.llm_client.call_llm_api(prompt=prompt) # 실제 클라이언트 메서드 사용
            logger.info(f"[{comic_id}] Received LLM response for evaluation.")

            # 3. 응답 정리 및 파싱
            parsed = self._clean_and_parse_response(raw_response, comic_id)

            # 4. 결정 추출 및 검증
            decision = "proceed" # 기본값
            comment = None
            error_msg_detail = None # 파싱/검증 실패 시 상세 메시지

            if parsed and isinstance(parsed, dict):
                llm_decision = parsed.get('decision')
                comment = parsed.get('comment', None) # 코멘트 추출 (없으면 None)

                if llm_decision in VALID_DECISIONS:
                    decision = llm_decision # 유효한 결정 사용
                    logger.info(f"[{comic_id}] LLM evaluation decision: '{decision}'. Comment: '{comment}'")
                elif llm_decision is not None:
                    # 유효하지 않은 결정값
                    error_msg_detail = f"Invalid decision value '{llm_decision}' received from LLM."
                    logger.warning(f"[{comic_id}] {error_msg_detail} Using default 'proceed'.")
                else:
                    # 'decision' 키 누락
                    error_msg_detail = "LLM evaluation response missing 'decision' key."
                    logger.warning(f"[{comic_id}] {error_msg_detail} Using default 'proceed'.")
            elif parsed is None:
                # JSON 파싱 실패
                 error_msg_detail = "Failed to parse LLM evaluation response."
                 logger.warning(f"[{comic_id}] {error_msg_detail} Using default 'proceed'.")
            else:
                 # 파싱 결과가 dict가 아님
                 error_msg_detail = "Parsed LLM evaluation response was not a JSON object."
                 logger.warning(f"[{comic_id}] {error_msg_detail} Using default 'proceed'.")

            # 최종 상태 업데이트 설정
            updates['summary_evaluation_decision'] = decision
            updates['summary_evaluation_comment'] = comment
            # 파싱/검증 중 경고가 발생했을 경우에만 에러 메시지 설정
            updates['error_message'] = error_msg_detail if error_msg_detail else None

        except Exception as e:
            # LLM 호출 실패 등 예외 처리
            err = f"Unexpected error during summary evaluation: {type(e).__name__}: {e}"
            logger.exception(f"[{comic_id}] {err}") # 스택 트레이스 포함 로깅
            updates['summary_evaluation_decision'] = 'proceed' # 심각한 에러 시 기본값 사용
            updates['error_message'] = err
        # --- 핵심 로직 종료 ---

        logger.info(f"--- [{comic_id}] [Evaluate Summary Agent] Completed. Decision: '{updates['summary_evaluation_decision']}' ---")
        return updates