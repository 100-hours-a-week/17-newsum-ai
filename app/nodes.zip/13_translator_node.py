# app/agents/translator_agent.py

class TranslatorAgent:
    async def run(self, state):
        """
        생성된 텍스트(대사 등)를 다른 언어로 번역합니다. (옵션)
        """
        # TODO: 번역 LLM 호출 추가
        return state
